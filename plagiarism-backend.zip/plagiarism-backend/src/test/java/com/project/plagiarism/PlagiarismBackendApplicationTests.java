package com.project.plagiarism;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlagiarismBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
