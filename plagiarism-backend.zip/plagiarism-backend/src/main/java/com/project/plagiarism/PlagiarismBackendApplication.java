package com.project.plagiarism;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlagiarismBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlagiarismBackendApplication.class, args);
	}

}
